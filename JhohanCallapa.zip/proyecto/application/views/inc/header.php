	<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Sistema web</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Jhohan Marco Callapa Mamani">
    <meta name="generator" content=" ">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>bootstrap/css/checkout.css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>bootstrap/css/form-validation.css">
</head>
<body>

